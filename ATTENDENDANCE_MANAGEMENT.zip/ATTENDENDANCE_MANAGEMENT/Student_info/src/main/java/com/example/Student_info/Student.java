package com.example.Student_info;
public class Student {
    private final int usn;
    private final String course;
    private final String subject;
    private final String faculty_id;
    private final String attendence;

    public Student(final int usn, final String course, final String subject, final String faculty_id, final String attendence) {
        this.usn = usn;
        this.course = course;
        this.subject = subject;
        this.faculty_id = faculty_id;
        this.attendence = attendence;
    }

    public int getUsn() {
        return usn;
    }

    public String getCourse() {
        return course;
    }

    public String getSubject() {
        return subject;
    }
    public String getFaculty_id()
    {
        return faculty_id;
    }
    public String getAttendence()
    {
        return attendence;
    }
}