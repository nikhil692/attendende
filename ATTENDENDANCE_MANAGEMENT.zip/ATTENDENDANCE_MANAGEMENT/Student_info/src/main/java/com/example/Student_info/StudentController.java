package com.example.Student_info;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import java.util.Arrays;
import java.util.List;
@RequestMapping("/students")
@RestController
public class StudentController {
    private final List<Student> students = Arrays.asList(
            new Student(1, "course a", "subject 1", "f1", "90"),
            new Student(2, "course b", "subject 2", "f2", "90"),
            new Student(3, "course c", "subject 3", "f3", "90"),
            new Student(4, "course d", "subject 4", "f4", "90"),
            new Student(5, "course e", "subject 5", "f5", "90"));

    @GetMapping
    public List<Student> getAllStudent() {
        return students;
    }

    @GetMapping("/{id}")
    public Student getStudentById(@PathVariable int id) {
        return students.stream()
                     .filter(order -> order.getUsn() == id)
                     .findFirst()
                     .orElseThrow(IllegalArgumentException::new);
    }
}