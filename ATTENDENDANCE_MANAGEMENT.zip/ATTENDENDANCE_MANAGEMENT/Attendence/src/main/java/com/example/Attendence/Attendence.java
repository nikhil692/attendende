package com.example.Attendence;
public class Attendence {
    private final int usn;
    private final String name;
    private final String semester;
    private final String branch;

    public Attendence(final int usn,  final String name, final String semester, final String branch) {
        this.usn = usn;
        this.name = name;
        this.semester=semester;
        this.branch=branch;
    }

    public int getUsn() {
        return usn;
    }

    public String getName() {
        return name;
    }
    public String getSemester()
    {
        return semester;
    }
    public String getBranch()
    {
        return branch;
    }
}