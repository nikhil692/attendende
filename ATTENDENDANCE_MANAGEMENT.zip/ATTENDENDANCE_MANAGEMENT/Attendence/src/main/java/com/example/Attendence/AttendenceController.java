package com.example.Attendence;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;
@RequestMapping("/attendences")
@RestController
public class AttendenceController {
    private List<Attendence> attendences = Arrays.asList(
            new Attendence(1, "anup", "7", "cse"),
            new Attendence(2, "nikhil", "7", "cse"),
            new Attendence(3, "kaushik", "7", "cse"));
    
    @GetMapping
    public List<Attendence> getAllAttendences() {
        return attendences;
    }
    
    @GetMapping("/{id}")
    public Attendence getAttendenceById(@PathVariable int id) {
        return attendences.stream()
                        .filter(attendence -> attendence.getUsn() == id)
                        .findFirst()
                        .orElseThrow(IllegalArgumentException::new);
    }
}