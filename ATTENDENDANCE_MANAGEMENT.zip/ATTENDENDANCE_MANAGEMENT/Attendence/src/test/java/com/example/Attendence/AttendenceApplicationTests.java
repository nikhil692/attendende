package com.example.Attendence;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AttendenceApplicationTests {

	@Test
	void contextLoads() {
	}

}
